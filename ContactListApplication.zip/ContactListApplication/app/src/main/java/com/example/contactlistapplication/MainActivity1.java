package com.example.contactlistapplication;
// ContactListAdapter.java

import android.annotation.SuppressLint;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity1 extends AppCompatActivity {

    private ArrayList<Contact> contactList;
    private ContactListAdapter contactListAdapter;
    private EditText etName, etPhoneNumber;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        Button btnAddContact = findViewById(R.id.btnAddContact);
        ListView lvContacts = findViewById(R.id.lvContacts);

        contactList = new ArrayList<>();
        contactListAdapter = new ContactListAdapter();
        lvContacts.setAdapter(contactListAdapter);

        btnAddContact.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String phoneNumber = etPhoneNumber.getText().toString().trim();

            if (name.isEmpty() || phoneNumber.isEmpty()) {
                Toast.makeText(MainActivity1.this, "Please enter name and phone number", Toast.LENGTH_SHORT).show();
            } else {
                Contact contact = new Contact();
                contactList.add(contact);
                contactListAdapter.notifyDataSetChanged();
                etName.setText("");
                etPhoneNumber.setText("");
            }
        });
    }

    private static class ContactListAdapter implements ListAdapter {

        public ContactListAdapter() {
        }

        public void notifyDataSetChanged() {

        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int i) {
            return false;
        }

        @Override
        public void registerDataSetObserver(DataSetObserver dataSetObserver) {

        }

        @Override
        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

        }

        @Override
        public int getCount() {
            return 0;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            return null;
        }

        @Override
        public int getItemViewType(int i) {
            return 0;
        }

        @Override
        public int getViewTypeCount() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }
    }

    private static class Contact {
        public Contact() {

        }
    }
}


@SuppressWarnings("ALL")
class MainActivity extends AppCompatActivity {

    public MainActivity() {
    }
// ContactListAdapter.java


    private static class Contact {
        public int getName() {
            return 0;
        }

        public int getPhoneNumber() {
            return 0;
        }
    }

    //// Contact.java
    //
    //public class Contact {
    //    private String name;
    //    private String phoneNumber;
    //
    //    public Contact(String name, String phoneNumber) {
    //        this.name = name;
    //        this.phoneNumber = phoneNumber;
    //    }
    //
    //    public String getName() {
    //        return name;
    //    }
    //
    //    public String getPhoneNumber() {
    //        return phoneNumber;
    //    }
    //} ContactListAdapter.java


}